"""Prime Automation Hub — webhook server.

Endpoints:
  POST /webhook         — QBO change notifications (auto-processes Invoice Create)
  POST /webhook/tap     — Tap payment capture notifications
  GET  /payment/success — customer lands here after Tap payment
  GET  /health          — liveness + config status
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, Header, HTTPException, Request, status
from fastapi.responses import FileResponse

from db.payment_links import bootstrap_links_from_file, init_table as init_payment_links_table
from logging_config import get_logger
from webhook.storage import count_all_events, get_recent_events, init_db, store_webhook_payload
from webhook.verify import verify_signature

_LOG = get_logger("webhook.server")

app = FastAPI(title="Prime Automation Hub", version="1.0.0")

_PUBLIC_DIR = Path(__file__).resolve().parent.parent / "public"
_PAYMENT_SUCCESS_PAGE = _PUBLIC_DIR / "payment" / "success.html"


@app.on_event("startup")
async def _startup() -> None:
    """Ensure SQLite tables exist before webhooks or background tasks run."""
    init_payment_links_table()
    init_db()
    bootstrap_links_from_file()
    _LOG.info("database_ready")


# ── QBO invoice processor (background task) ───────────────────────────────────

def _process_qbo_invoice(invoice_id: str) -> None:
    """Run the full invoice → Tap link → WhatsApp workflow in the background.

    Called when QBO fires an Invoice Create event. Runs after the webhook
    has already returned 200 to Intuit, so processing time doesn't matter.
    """
    try:
        from config import get_settings
        from qbo.client import QuickBooksClient
        from tap.client import tap_client_from_settings
        from messaging.whatsapp import whatsapp_client_from_settings
        from workflows.invoice_to_tap import process_invoice, LinkResult, SkipResult

        settings  = get_settings()
        qbo       = QuickBooksClient(settings=settings)
        tap       = tap_client_from_settings(settings)
        whatsapp  = whatsapp_client_from_settings(settings)

        result = process_invoice(
            invoice_id,
            qbo_client=qbo,
            tap_client=tap,
            whatsapp_client=whatsapp,
            settings=settings,
        )

        if isinstance(result, SkipResult):
            _LOG.info("qbo_invoice_skipped",
                      extra={"invoice_id": invoice_id, "reason": result.reason})
        elif isinstance(result, LinkResult):
            _LOG.info("qbo_invoice_processed",
                      extra={
                          "invoice_id": invoice_id,
                          "tap_charge_id": result.tap_charge_id,
                          "whatsapp_sent": result.whatsapp_sent,
                          "status": result.status,
                      })
    except Exception as exc:
        _LOG.error("qbo_invoice_process_error",
                   extra={"invoice_id": invoice_id, "error": str(exc)})


# ── QBO webhook ───────────────────────────────────────────────────────────────

@app.post("/webhook", status_code=status.HTTP_200_OK)
async def receive_qbo_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    intuit_signature: str | None = Header(default=None, alias="intuit-signature"),
) -> dict:
    """Receive QBO change notification, verify, store, and process Invoice Creates."""
    payload_bytes: bytes = await request.body()
    verifier_token = os.getenv("QBO_WEBHOOK_VERIFIER_TOKEN", "").strip()

    if not verifier_token:
        raise HTTPException(status_code=500, detail="QBO_WEBHOOK_VERIFIER_TOKEN not set")

    if not verify_signature(payload_bytes, intuit_signature or "", verifier_token):
        _LOG.warning("qbo_webhook_invalid_signature")
        raise HTTPException(status_code=401, detail="Invalid intuit-signature")

    try:
        payload = json.loads(payload_bytes)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    events_stored = store_webhook_payload(payload, payload_bytes.decode("utf-8"))

    # ── auto-process Invoice Create events ────────────────────────────────────
    invoice_ids_to_process: list[str] = []
    for notification in payload.get("eventNotifications", []):
        entities = notification.get("dataChangeEvent", {}).get("entities", [])
        for entity in entities:
            if entity.get("name") == "Invoice" and entity.get("operation") == "Create":
                invoice_ids_to_process.append(entity["id"])

    for invoice_id in invoice_ids_to_process:
        _LOG.info("qbo_invoice_create_detected", extra={"invoice_id": invoice_id})
        background_tasks.add_task(_process_qbo_invoice, invoice_id)

    _LOG.info("qbo_webhook_received",
              extra={"events_stored": events_stored,
                     "invoices_queued": len(invoice_ids_to_process)})

    return {
        "status": "ok",
        "events_stored": events_stored,
        "invoices_queued": len(invoice_ids_to_process),
    }


# ── Tap webhook ───────────────────────────────────────────────────────────────

@app.post("/webhook/tap", status_code=status.HTTP_200_OK)
async def receive_tap_webhook(request: Request) -> dict:
    """Handle Tap charge.captured — marks QBO invoice paid + sends WhatsApp."""
    payload_bytes: bytes = await request.body()

    try:
        payload = json.loads(payload_bytes)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    tap_id = payload.get("id", "")
    tap_object = payload.get("object", "")

    if tap_id.startswith("inv_") or tap_object == "invoice":
        tap_status = payload.get("status", "")
        amount = float(payload.get("amount", 0))
        currency = payload.get("currency", "KWD")

        _LOG.info(
            "tap_invoice_webhook_received",
            extra={"invoice_id": tap_id, "status": tap_status},
        )

        if tap_status != "PAID":
            return {"status": "ignored", "tap_status": tap_status}

        if not tap_id:
            raise HTTPException(status_code=400, detail="Missing invoice id")

        capture_ref = tap_id
        transactions = payload.get("transactions") or []
        if transactions:
            capture_ref = str(transactions[0].get("id") or tap_id)
    else:
        charge_id = tap_id
        charge_status = payload.get("status", "")
        amount = float(payload.get("amount", 0))
        currency = payload.get("currency", "KWD")

        _LOG.info("tap_webhook_received",
                  extra={"charge_id": charge_id, "status": charge_status})

        if charge_status != "CAPTURED":
            return {"status": "ignored", "charge_status": charge_status}

        if not charge_id:
            raise HTTPException(status_code=400, detail="Missing charge id")

        capture_ref = charge_id

    try:
        from config import get_settings
        from qbo.client import QuickBooksClient
        from messaging.whatsapp import whatsapp_client_from_settings
        from workflows.payment_capture import (
            handle_payment_capture, CaptureResult, CaptureError
        )

        settings = get_settings()
        qbo      = QuickBooksClient(settings=settings)
        wa       = whatsapp_client_from_settings(settings)

        result = handle_payment_capture(
            tap_id if (tap_id.startswith("inv_") or tap_object == "invoice") else capture_ref,
            amount, currency,
            qbo_client=qbo,
            whatsapp_client=wa,
            tap_payment_ref=capture_ref,
        )

        if isinstance(result, CaptureError):
            if result.reason == "CHARGE_NOT_FOUND":
                return {"status": "unknown_charge"}
            raise HTTPException(status_code=500, detail=result.detail)

        return {
            "status": "ok",
            "capture_status": result.status,
            "invoice_id": result.invoice_id,
            "qbo_payment_id": result.qbo_payment_id,
            "whatsapp_sent": result.whatsapp_sent,
        }

    except HTTPException:
        raise
    except Exception as exc:
        _LOG.error("tap_webhook_error", extra={"error": str(exc)})
        raise HTTPException(status_code=500, detail=str(exc))


# ── Tap payment redirect landing page ─────────────────────────────────────────

@app.get("/payment/success")
async def payment_success() -> FileResponse:
    """Landing page after Tap redirects the customer back from checkout."""
    if not _PAYMENT_SUCCESS_PAGE.is_file():
        raise HTTPException(status_code=500, detail="Payment success page not found")
    return FileResponse(_PAYMENT_SUCCESS_PAGE, media_type="text/html; charset=utf-8")


# ── health ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health() -> dict:
    return {
        "status": "healthy",
        "qbo_token_configured": bool(os.getenv("QBO_WEBHOOK_VERIFIER_TOKEN", "")),
        "tap_events_stored": count_all_events(),
        "recent_events": get_recent_events(limit=5),
    }
